﻿namespace $safeprojectname$.MyModule.Models
{
    public class Sample
    {
        public int ModuleId { get; set; }

        public string Name { get; set; }
    }
}
