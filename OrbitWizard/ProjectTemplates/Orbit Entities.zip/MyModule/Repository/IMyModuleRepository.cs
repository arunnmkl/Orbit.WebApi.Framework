﻿using $safeprojectname$.MyModule.Models;

namespace $safeprojectname$.MyModule.Repository
{
    internal interface IMyModuleRepository
    {
        bool Create(Sample model);

        bool Update(Sample model);

        Sample Read(int mduleId);

        bool Delete(int mduleId);
    }
}
