﻿var configData = {
  "Config": {
    "chatHubs": "http://localhost/OAuth.Messaging/signalr/hubs",
    "chatUrl": "http://localhost/OAuth.Messaging/signalr",
    "serviceBase": "http://localhost/OAuth.Api/",
    "version": "1.0"
  },
  "localhost": {
    "chatHubs": "http://localhost:50534/signalr/hubs",
    "chatUrl": "http://localhost:50534/signalr",
    "serviceBase": "http://localhost:53937/"
  }
}