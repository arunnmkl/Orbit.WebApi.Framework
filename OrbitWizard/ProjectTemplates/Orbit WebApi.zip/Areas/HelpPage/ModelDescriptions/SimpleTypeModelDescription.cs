namespace $safeprojectname$.Areas.HelpPage.ModelDescriptions
{
    /// <summary>
    ///Simple Type Model Description
    /// </summary>
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}