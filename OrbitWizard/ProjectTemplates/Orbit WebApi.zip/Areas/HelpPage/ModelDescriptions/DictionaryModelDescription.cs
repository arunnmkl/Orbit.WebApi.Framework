namespace $safeprojectname$.Areas.HelpPage.ModelDescriptions
{
    /// <summary>
    /// Dictionary Model Description
    /// </summary>
    public class DictionaryModelDescription : KeyValuePairModelDescription
    {
    }
}