namespace $safeprojectname$.Areas.HelpPage.ModelDescriptions
{
    /// <summary>
    /// Collection Type Model Description
    /// </summary>
    public class CollectionModelDescription : ModelDescription
    {
        public ModelDescription ElementDescription { get; set; }
    }
}